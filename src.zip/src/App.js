import React, { Component } from 'react'
import './App.css';
import SmallButton from './Buttons/SmallButton';
import LargeButton from './Buttons/LargeButton';
import TextInput from './Inputs/TextInput';
import TextAreaInput from './Inputs/TextAreaInput';
import SelectInput from './Inputs/SelectInput';
import CheckboxInput from './Inputs/CheckboxInput';
import RadioInput from './Inputs/RadioInput';
import SwitchInput from './Inputs/SwitchInput';

class App extends Component {

  state = {
    typing: "false",
    value: "",
    requireMessage: "", 
    success: "pending"
  }

  handleInputOnBlur = () => {
    if (this.state.value.length === 0) {
        this.setState({requireMessage: "Required"})
    }
  }

  handleInputOnChange = (event) => {
    this.setState({value: event.target.value});
    if (event.target.value.length > 0) {
      this.setState({requireMessage: ""});
      this.setState({typing: "true"});
    } else {
      this.setState({typing: "false"})
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    if (this.state.requireMessage) {
        this.setState({success: "failure"})
    }
  }

  render(){
    return (
      <div className="App">
        <div className="HeaderBox-Top"></div>
        <div className="HeaderBox-Bottom">The Formy Form</div>
        <form>
          <TextInput 
           typing
           value
           requiredMessage
           success
           inputBlur={this.handleInputOnBlur}
           inputOnChange={this.handleInputOnChange} />
          <br></br>
          <br></br>
          <TextAreaInput />
          <br></br>
          <br></br>
          <SelectInput />
          <br></br>
          <br></br>
          <CheckboxInput />
          <br></br>
          <br></br>
          <RadioInput />
          <br></br>
          <br></br>
          <SwitchInput />
          <br></br>
          <br></br>
          <SmallButton submit={this.handleSubmit}/>
          <LargeButton />
        </form>
      </div>
    );
  }
 
}

export default App;
